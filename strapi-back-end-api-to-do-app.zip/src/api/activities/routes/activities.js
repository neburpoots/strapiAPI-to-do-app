module.exports = {
  routes: [
    // {
    //  method: 'GET',
    //  path: '/activities',
    //  handler: 'activities.exampleAction',
    //  config: {
    //    policies: [],
    //    middlewares: [],
    //  },
    // },
  ],
};
