'use strict';

/**
 * activities service.
 */

module.exports = () => ({});
