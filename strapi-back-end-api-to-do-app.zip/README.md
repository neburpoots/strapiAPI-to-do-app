#Back-end API of the nextjs to do app:

Created by Ruben Stoop

To use this project:
1. clone the project
2. npm install
3. npm run develop

To run build
1. npm run build
2. npm start

Login for the admin panel:
Email: rubenstoop@example.com
Password: Secret123

Git from the client app: https://github.com/neburpoots/next-js-to-do-app
